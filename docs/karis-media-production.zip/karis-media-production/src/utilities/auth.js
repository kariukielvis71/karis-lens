/**
 * auth.js
 * -----------------------------------------------------------------------
 * MOCK admin auth for the prototype stage — checks a hardcoded
 * credential pair and keeps the session in memory only (resets on
 * page refresh).
 *
 * When the Cloudflare Worker auth endpoint is live, replace the body of
 * checkCredentials() with a fetch("/api/admin/login", ...) call, and
 * persist the returned token the same way the original helpers.js did
 * (window.localStorage, guarded by try/catch) instead of the in-memory
 * flag below. Every call site here (app.js) stays the same either way.
 * -----------------------------------------------------------------------
 */

const MOCK_USERNAME = "admin";
const MOCK_PASSWORD = "admin123";

let authed = false;

export function checkCredentials(username, password) {
  return username === MOCK_USERNAME && password === MOCK_PASSWORD;
}

export function isAdminAuthed() {
  return authed;
}

export function setAdminAuthed(value) {
  authed = Boolean(value);
}
