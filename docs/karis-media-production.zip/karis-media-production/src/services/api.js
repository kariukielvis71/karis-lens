/**
 * api.js
 * -----------------------------------------------------------------------
 * Thin async client. Every function here already has the shape it will
 * have once the Cloudflare Worker is live (async, returns a Promise) —
 * only the function BODIES change when that happens, e.g.:
 *
 *   export async function fetchContent() {
 *     const res = await fetch("/api/content");
 *     return res.json();
 *   }
 *
 * Nothing outside this file (dataLoader.js) needs to change when that
 * swap happens. In-memory arrays here stand in for D1 + R2 for now.
 * -----------------------------------------------------------------------
 */

import { BUSINESS, SERVICES, CONTENT_SEED, LEADS_SEED } from "./mockData.js";

let content = CONTENT_SEED.slice();
let leads = LEADS_SEED.slice();

export async function fetchBusiness() {
  return BUSINESS;
}

export async function fetchServices() {
  return SERVICES;
}

export async function fetchContent() {
  return content;
}

export async function createContent(fields) {
  const id = content.reduce((max, item) => Math.max(max, item.id), 0) + 1;
  const item = { id, ...fields };
  content = [item, ...content];
  return item;
}

export async function updateContent(id, patch) {
  content = content.map((item) => (String(item.id) === String(id) ? { ...item, ...patch } : item));
  return content.find((item) => String(item.id) === String(id));
}

export async function deleteContent(id) {
  content = content.filter((item) => String(item.id) !== String(id));
  return { ok: true };
}

export async function fetchLeads() {
  return leads;
}

export async function createLead(fields) {
  const id = leads.reduce((max, item) => Math.max(max, item.id), 0) + 1;
  const lead = { id, status: "new", submittedAt: new Date().toISOString(), ...fields };
  leads = [lead, ...leads];
  return lead;
}

export async function updateLeadStatus(id, status) {
  leads = leads.map((lead) => (String(lead.id) === String(id) ? { ...lead, status } : lead));
  return leads.find((lead) => String(lead.id) === String(id));
}

/** Mock admin login — swap for a real POST /api/admin/login call later. */
export async function adminLogin(username, password) {
  const ok = username === "admin" && password === "admin123";
  return ok ? { ok: true, token: "mock-token" } : { ok: false, error: "Invalid credentials." };
}
