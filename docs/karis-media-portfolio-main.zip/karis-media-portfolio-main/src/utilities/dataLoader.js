/**
 * dataLoader.js
 * -----------------------------------------------------------------------
 * Dynamic fetch layer that orchestrates application state loading.
 *
 * Responsibility:
 *   - Load core config/content (business metadata, services list) from
 *     the local /data/*.json files, since these are static/rarely change.
 *   - Load the gallery from the Cloudflare edge API (D1 + R2), and
 *     transparently fall back to the local settings.json mock dataset
 *     if the network is unavailable or the API call fails.
 *
 * Consumers (app.js) get a single, consistent async interface regardless
 * of where the data actually came from, plus a `source` flag so the UI
 * can optionally indicate "showing cached/offline data".
 * -----------------------------------------------------------------------
 */

import { apiClient } from "../utilities/api.js";

const DATA_PATHS = {
  config: "/data/config.json",
  content: "/data/content.json",
  settings: "/data/settings.json",
};

/** Simple in-memory cache so repeated calls within a session are cheap. */
const cache = {
  config: null,
  content: null,
  gallery: null,
};

/**
 * Fetch and parse a local JSON file shipped with the app.
 * @param {string} path
 */
async function loadLocalJson(path) {
  const response = await fetch(path, { headers: { Accept: "application/json" } });
  if (!response.ok) {
    throw new Error(`[dataLoader] Failed to load local file "${path}" (status ${response.status})`);
  }
  return response.json();
}

/**
 * Load core business configuration (config.json). Cached after first load.
 * @param {boolean} [forceRefresh=false]
 */
export async function loadConfig(forceRefresh = false) {
  if (cache.config && !forceRefresh) return cache.config;
  cache.config = await loadLocalJson(DATA_PATHS.config);
  return cache.config;
}

/**
 * Load static service/content listing (content.json). Cached after first load.
 * @param {boolean} [forceRefresh=false]
 */
export async function loadContent(forceRefresh = false) {
  if (cache.content && !forceRefresh) return cache.content;
  cache.content = await loadLocalJson(DATA_PATHS.content);
  return cache.content;
}

/**
 * Determine, cheaply, whether the browser currently believes it has
 * network connectivity. This is a heuristic only -- the real signal is
 * whether the subsequent fetch call actually succeeds.
 */
function isProbablyOnline() {
  return typeof navigator === "undefined" || navigator.onLine !== false;
}

/**
 * Load the gallery, preferring the live Cloudflare Worker API
 * (D1 + R2) and gracefully degrading to the local settings.json
 * mock dataset if the network is unavailable or the API errors out.
 *
 * @param {Object} [params] - optional filter params forwarded to the API (e.g. category)
 * @param {Object} [options]
 * @param {boolean} [options.forceRefresh=false] - bypass in-memory cache
 * @returns {Promise<{ items: Array, source: 'cloud'|'local-fallback', error?: string }>}
 */
export async function loadGallery(params = {}, options = {}) {
  const { forceRefresh = false } = options;

  if (cache.gallery && !forceRefresh) return cache.gallery;

  if (isProbablyOnline()) {
    try {
      const cloudResponse = await apiClient.fetchGallery(params);
      const items = Array.isArray(cloudResponse) ? cloudResponse : cloudResponse?.items || [];

      const result = { items, source: "cloud" };
      cache.gallery = result;
      return result;
    } catch (err) {
      console.warn(
        "[dataLoader] Cloud gallery fetch failed, falling back to local settings.json:",
        err.message
      );
      return loadLocalGalleryFallback(err.message);
    }
  }

  console.info("[dataLoader] Offline detected, using local settings.json fallback.");
  return loadLocalGalleryFallback("offline");
}

/**
 * Internal helper: load the bundled settings.json mock gallery.
 * @param {string} [reason]
 */
async function loadLocalGalleryFallback(reason) {
  try {
    const localData = await loadLocalJson(DATA_PATHS.settings);
    const result = {
      items: localData.gallery || [],
      source: "local-fallback",
      error: reason,
    };
    cache.gallery = result;
    return result;
  } catch (fallbackErr) {
    console.error("[dataLoader] Local fallback also failed:", fallbackErr);
    return { items: [], source: "local-fallback", error: fallbackErr.message };
  }
}

/**
 * Bootstrap everything the app needs on startup in parallel: config,
 * content, and gallery (cloud-first with fallback).
 * @returns {Promise<{ config: Object, content: Object, gallery: Object }>}
 */
export async function bootstrapAppState() {
  const [config, content, gallery] = await Promise.all([
    loadConfig(),
    loadContent(),
    loadGallery(),
  ]);

  return { config, content, gallery };
}

/**
 * Clear the in-memory cache (useful after an admin upload/delete so the
 * next gallery read reflects fresh cloud state).
 * @param {'config'|'content'|'gallery'|'all'} [key='all']
 */
export function invalidateCache(key = "all") {
  if (key === "all") {
    cache.config = null;
    cache.content = null;
    cache.gallery = null;
    return;
  }
  cache[key] = null;
}
