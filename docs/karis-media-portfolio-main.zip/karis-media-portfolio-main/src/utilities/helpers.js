/**
 * helpers.js
 * -----------------------------------------------------------------------
 * Global, framework-agnostic DOM injection utilities and lightweight
 * admin-token storage hooks. Every other module (app.js, dataLoader.js,
 * booking.js, whatsapp.js) leans on these primitives instead of touching
 * `document` or `localStorage` directly, so the DOM/storage boundary
 * stays in exactly one place.
 * -----------------------------------------------------------------------
 */

/* ------------------------------------------------------------------ */
/*  DOM injection                                                      */
/* ------------------------------------------------------------------ */

/**
 * Resolve a target element from a selector string or an existing node.
 * @param {string|HTMLElement} target
 * @returns {HTMLElement|null}
 */
function resolveTarget(target) {
  if (typeof target === "string") {
    return document.querySelector(target);
  }
  if (target instanceof HTMLElement) {
    return target;
  }
  return null;
}

/**
 * Render a "component" into a target container.
 *
 * A component may be:
 *  - a string of pre-built HTML markup (produced by the presentation layer)
 *  - an HTMLElement / DocumentFragment node
 *  - a function that returns either of the above (lazy component)
 *
 * This function purely handles injection/mounting; it does not know or
 * care how the markup was constructed (that responsibility belongs to
 * the presentation layer's DOM wrappers).
 *
 * @param {string|HTMLElement} target - selector or element to render into
 * @param {string|HTMLElement|DocumentFragment|Function} component
 * @param {Object} [options]
 * @param {boolean} [options.append=false] - append instead of replacing content
 * @returns {HTMLElement|null} the resolved target element
 */
export function renderElement(target, component, options = {}) {
  const { append = false } = options;
  const node = resolveTarget(target);

  if (!node) {
    console.warn(`[helpers] renderElement: target "${target}" not found in DOM.`);
    return null;
  }

  let resolvedComponent = typeof component === "function" ? component() : component;

  if (!append) {
    node.innerHTML = "";
  }

  if (typeof resolvedComponent === "string") {
    if (append) {
      node.insertAdjacentHTML("beforeend", resolvedComponent);
    } else {
      node.innerHTML = resolvedComponent;
    }
  } else if (
    resolvedComponent instanceof HTMLElement ||
    resolvedComponent instanceof DocumentFragment
  ) {
    node.appendChild(resolvedComponent);
  } else if (resolvedComponent != null) {
    console.warn("[helpers] renderElement: unsupported component type.", resolvedComponent);
  }

  return node;
}

/**
 * Toggle visibility of an element using a class hook rather than inline
 * styles, so the presentation layer retains full control over the CSS.
 * @param {string|HTMLElement} target
 * @param {boolean} isVisible
 * @param {string} [hiddenClass="is-hidden"]
 */
export function toggleVisibility(target, isVisible, hiddenClass = "is-hidden") {
  const node = resolveTarget(target);
  if (!node) return;
  node.classList.toggle(hiddenClass, !isVisible);
}

/**
 * Clear all children from a target node.
 * @param {string|HTMLElement} target
 */
export function clearElement(target) {
  const node = resolveTarget(target);
  if (node) node.innerHTML = "";
}

/**
 * Lightweight event delegation helper. Attaches a single listener to a
 * root/container and dispatches to any descendant matching `selector`.
 *
 * @param {string|HTMLElement} root - delegation root (defaults to document)
 * @param {string} eventType - e.g. "click"
 * @param {string} selector - CSS selector to match against event.target
 * @param {(event: Event, matchedElement: HTMLElement) => void} handler
 * @returns {() => void} unsubscribe function
 */
export function delegate(root, eventType, selector, handler) {
  const rootNode = resolveTarget(root) || document;

  const listener = (event) => {
    const matched = event.target.closest(selector);
    if (matched && rootNode.contains(matched)) {
      handler(event, matched);
    }
  };

  rootNode.addEventListener(eventType, listener);
  return () => rootNode.removeEventListener(eventType, listener);
}

/* ------------------------------------------------------------------ */
/*  Admin token storage hooks                                          */
/* ------------------------------------------------------------------ */

const DEFAULT_TOKEN_KEY = "studio_admin_token";

/**
 * Persist an admin session token (e.g. after a successful login call to
 * a Cloudflare Worker auth endpoint).
 * @param {string} token
 * @param {string} [storageKey]
 */
export function setAdminToken(token, storageKey = DEFAULT_TOKEN_KEY) {
  try {
    window.localStorage.setItem(storageKey, token);
  } catch (err) {
    console.error("[helpers] Unable to persist admin token:", err);
  }
}

/**
 * Retrieve the stored admin token, if any.
 * @param {string} [storageKey]
 * @returns {string|null}
 */
export function getAdminToken(storageKey = DEFAULT_TOKEN_KEY) {
  try {
    return window.localStorage.getItem(storageKey);
  } catch (err) {
    console.error("[helpers] Unable to read admin token:", err);
    return null;
  }
}

/**
 * Remove the stored admin token (logout).
 * @param {string} [storageKey]
 */
export function clearAdminToken(storageKey = DEFAULT_TOKEN_KEY) {
  try {
    window.localStorage.removeItem(storageKey);
  } catch (err) {
    console.error("[helpers] Unable to clear admin token:", err);
  }
}

/**
 * Basic boolean gate: is there a non-empty admin token present?
 * This does NOT validate the token against the server -- it is a fast,
 * client-side gate only. Server-side routes must always re-validate.
 * @param {string} [storageKey]
 * @returns {boolean}
 */
export function hasAdminToken(storageKey = DEFAULT_TOKEN_KEY) {
  const token = getAdminToken(storageKey);
  return typeof token === "string" && token.trim().length > 0;
}

/* ------------------------------------------------------------------ */
/*  Misc small utilities                                               */
/* ------------------------------------------------------------------ */

/**
 * Debounce a function call.
 * @param {Function} fn
 * @param {number} [wait=250]
 */
export function debounce(fn, wait = 250) {
  let timeoutId;
  return (...args) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => fn(...args), wait);
  };
}

/**
 * Simple unique-id generator for client-generated records
 * (e.g. optimistic gallery items before server confirmation).
 */
export function generateId(prefix = "id") {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
