/**
 * api.js
 * -----------------------------------------------------------------------
 * Thin async client for the Cloudflare Edge backend (Worker + D1 + R2).
 * Handles:
 *   - GET  /api/gallery   -> list gallery records (backed by D1, assets in R2)
 *   - POST /api/upload    -> upload a file (multipart/form-data) to R2 + D1
 *
 * Every request that requires authorization pulls the admin token via
 * helpers.js so the token storage mechanism stays centralized.
 * -----------------------------------------------------------------------
 */

import { getAdminToken } from "./helpers.js";

const DEFAULT_BASE_URL = "";
const DEFAULT_ENDPOINTS = {
  gallery: "/api/gallery",
  upload: "/api/upload",
};

const DEFAULT_TIMEOUT_MS = 15000;

/**
 * Wrap fetch with a timeout so a hung edge function doesn't stall the UI.
 * @param {string} url
 * @param {RequestInit} options
 * @param {number} timeoutMs
 */
async function fetchWithTimeout(url, options = {}, timeoutMs = DEFAULT_TIMEOUT_MS) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    return response;
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * Build standard headers, optionally attaching the Bearer admin token.
 * @param {boolean} withAuth
 * @param {Object} [extra]
 */
function buildHeaders(withAuth = false, extra = {}) {
  const headers = { ...extra };

  if (withAuth) {
    const token = getAdminToken();
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }
  }

  return headers;
}

/**
 * Parse a fetch Response as JSON, throwing a normalized error on failure.
 * @param {Response} response
 */
async function parseJsonOrThrow(response) {
  let body = null;
  try {
    body = await response.json();
  } catch {
    // response had no/invalid JSON body; fall through to status check
  }

  if (!response.ok) {
    const message = body?.error || body?.message || `Request failed with status ${response.status}`;
    const error = new Error(message);
    error.status = response.status;
    error.body = body;
    throw error;
  }

  return body;
}

/**
 * Factory that creates a configured API client. Allows the base URL /
 * endpoints to be overridden (e.g. from config.json) without touching
 * module internals.
 *
 * @param {Object} [config]
 * @param {string} [config.baseUrl]
 * @param {Object} [config.endpoints]
 * @param {number} [config.timeoutMs]
 */
export function createApiClient(config = {}) {
  const baseUrl = config.baseUrl ?? DEFAULT_BASE_URL;
  const endpoints = { ...DEFAULT_ENDPOINTS, ...(config.endpoints || {}) };
  const timeoutMs = config.timeoutMs ?? DEFAULT_TIMEOUT_MS;

  /**
   * GET /api/gallery
   * Fetch the current gallery listing from D1 (via the Worker).
   * @param {Object} [params] - optional query params, e.g. { category: 'weddings' }
   */
  async function fetchGallery(params = {}) {
    const url = new URL(`${baseUrl}${endpoints.gallery}`, window.location.origin);
    Object.entries(params).forEach(([key, value]) => {
      if (value != null && value !== "") url.searchParams.set(key, value);
    });

    const response = await fetchWithTimeout(
      url.toString(),
      {
        method: "GET",
        headers: buildHeaders(true, { Accept: "application/json" }),
      },
      timeoutMs
    );

    return parseJsonOrThrow(response);
  }

  /**
   * POST /api/upload
   * Upload a single file (and optional metadata) to R2, with the D1
   * record created server-side by the Worker.
   *
   * @param {File|Blob} file
   * @param {Object} [metadata] - e.g. { title, category, type }
   * @param {(percent: number) => void} [onProgress] - optional progress callback
   */
  async function uploadFile(file, metadata = {}, onProgress) {
    if (!file) {
      throw new Error("[api] uploadFile: a File or Blob is required.");
    }

    const formData = new FormData();
    formData.append("file", file, file.name || "upload.bin");
    Object.entries(metadata).forEach(([key, value]) => {
      formData.append(key, value ?? "");
    });

    // Use XHR when a progress callback is supplied, since fetch has no
    // native upload-progress event; otherwise use fetch for simplicity.
    if (typeof onProgress === "function") {
      return uploadWithProgress(`${baseUrl}${endpoints.upload}`, formData, onProgress);
    }

    const response = await fetchWithTimeout(
      `${baseUrl}${endpoints.upload}`,
      {
        method: "POST",
        headers: buildHeaders(true),
        body: formData,
      },
      timeoutMs
    );

    return parseJsonOrThrow(response);
  }

  /**
   * XHR-based upload path so we can surface progress percentage to the
   * presentation layer (e.g. a progress bar component).
   */
  function uploadWithProgress(url, formData, onProgress) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", url, true);

      const token = getAdminToken();
      if (token) {
        xhr.setRequestHeader("Authorization", `Bearer ${token}`);
      }

      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable) {
          onProgress(Math.round((event.loaded / event.total) * 100));
        }
      };

      xhr.onload = () => {
        let body = null;
        try {
          body = JSON.parse(xhr.responseText);
        } catch {
          // ignore parse failure; handled below via status check
        }

        if (xhr.status >= 200 && xhr.status < 300) {
          resolve(body);
        } else {
          const message = body?.error || body?.message || `Upload failed with status ${xhr.status}`;
          const error = new Error(message);
          error.status = xhr.status;
          error.body = body;
          reject(error);
        }
      };

      xhr.onerror = () => reject(new Error("[api] Network error during upload."));
      xhr.ontimeout = () => reject(new Error("[api] Upload timed out."));

      xhr.send(formData);
    });
  }

  /**
   * DELETE /api/gallery/:id
   * Remove a gallery item (D1 record + associated R2 object) by id.
   * @param {string} id
   */
  async function deleteGalleryItem(id) {
    const url = `${baseUrl}${endpoints.gallery}/${encodeURIComponent(id)}`;

    const response = await fetchWithTimeout(
      url,
      {
        method: "DELETE",
        headers: buildHeaders(true, { Accept: "application/json" }),
      },
      timeoutMs
    );

    return parseJsonOrThrow(response);
  }

  return {
    fetchGallery,
    uploadFile,
    deleteGalleryItem,
  };
}

/** Default, ready-to-use client instance using the module defaults. */
export const apiClient = createApiClient();
