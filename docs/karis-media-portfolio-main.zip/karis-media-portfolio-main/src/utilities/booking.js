/**
 * booking.js
 * -----------------------------------------------------------------------
 * Form parsing / validation module for booking requests.
 * Responsible for:
 *   - sanitizing raw text inputs
 *   - validating required fields and date restrictions
 *   - building a normalized payload consumed by whatsapp.js and/or api.js
 *
 * This module never touches the DOM directly beyond reading a FormData
 * object or plain field map handed to it by app.js / the presentation
 * layer's form wrapper.
 * -----------------------------------------------------------------------
 */

/** Fields every booking submission must contain. */
const REQUIRED_FIELDS = ["fullName", "phone", "service", "eventDate"];

/** How many days in advance a booking must be made (lead time). */
const MIN_LEAD_DAYS = 2;

/** How far into the future a booking may be scheduled. */
const MAX_LEAD_DAYS = 365;

/* ------------------------------------------------------------------ */
/*  Sanitization                                                       */
/* ------------------------------------------------------------------ */

/**
 * Strip HTML tags, collapse whitespace, and trim a raw text value.
 * Prevents naive markup/script injection from free-text fields before
 * they are ever templated into a WhatsApp message or sent to the API.
 * @param {*} value
 * @returns {string}
 */
export function sanitizeText(value) {
  if (value == null) return "";
  const str = String(value);
  return str
    .replace(/<[^>]*>/g, "")
    .replace(/[\u0000-\u001F\u007F]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Sanitize a phone number down to a leading "+" (optional) and digits.
 * @param {*} value
 * @returns {string}
 */
export function sanitizePhone(value) {
  if (value == null) return "";
  const str = String(value).trim();
  const hasPlus = str.startsWith("+");
  const digits = str.replace(/\D/g, "");
  return hasPlus ? `+${digits}` : digits;
}

/**
 * Normalize a FormData instance or plain object into a flat string map,
 * sanitizing every value along the way.
 * @param {FormData|Object} source
 * @returns {Object<string, string>}
 */
export function extractFormFields(source) {
  const rawEntries =
    source instanceof FormData ? Array.from(source.entries()) : Object.entries(source || {});

  const fields = {};
  for (const [key, value] of rawEntries) {
    fields[key] = key.toLowerCase().includes("phone") ? sanitizePhone(value) : sanitizeText(value);
  }
  return fields;
}

/* ------------------------------------------------------------------ */
/*  Date validation                                                     */
/* ------------------------------------------------------------------ */

/**
 * Validate that a date string is a real, parseable date within the
 * allowed booking window (not in the past, not absurdly far out).
 * @param {string} dateStr - expected format: YYYY-MM-DD (native <input type="date">)
 * @returns {{ valid: boolean, reason?: string }}
 */
export function validateEventDate(dateStr) {
  if (!dateStr) {
    return { valid: false, reason: "Event date is required." };
  }

  const parsed = new Date(`${dateStr}T00:00:00`);
  if (Number.isNaN(parsed.getTime())) {
    return { valid: false, reason: "Event date is not a valid date." };
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const diffDays = Math.round((parsed - today) / (1000 * 60 * 60 * 24));

  if (diffDays < MIN_LEAD_DAYS) {
    return {
      valid: false,
      reason: `Bookings require at least ${MIN_LEAD_DAYS} day(s) advance notice.`,
    };
  }

  if (diffDays > MAX_LEAD_DAYS) {
    return {
      valid: false,
      reason: `Bookings cannot be made more than ${MAX_LEAD_DAYS} days in advance.`,
    };
  }

  return { valid: true };
}

/* ------------------------------------------------------------------ */
/*  Field-level validation                                             */
/* ------------------------------------------------------------------ */

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_PATTERN = /^\+?\d{9,15}$/;

/**
 * Validate a sanitized field map against required-field and format rules.
 * @param {Object<string, string>} fields
 * @returns {{ valid: boolean, errors: Object<string, string> }}
 */
export function validateBookingFields(fields) {
  const errors = {};

  for (const key of REQUIRED_FIELDS) {
    if (!fields[key] || fields[key].trim().length === 0) {
      errors[key] = "This field is required.";
    }
  }

  if (fields.phone && !PHONE_PATTERN.test(fields.phone)) {
    errors.phone = "Enter a valid phone number (digits only, 9-15 characters).";
  }

  if (fields.email && !EMAIL_PATTERN.test(fields.email)) {
    errors.email = "Enter a valid email address.";
  }

  if (fields.eventDate) {
    const dateCheck = validateEventDate(fields.eventDate);
    if (!dateCheck.valid) {
      errors.eventDate = dateCheck.reason;
    }
  }

  return { valid: Object.keys(errors).length === 0, errors };
}

/* ------------------------------------------------------------------ */
/*  Payload construction                                               */
/* ------------------------------------------------------------------ */

/**
 * Build a normalized booking payload ready to be:
 *   - handed to whatsapp.js for message templating, and/or
 *   - POSTed to the cloud API via api.js
 *
 * @param {FormData|Object} source - raw form data
 * @returns {{ ok: boolean, payload?: Object, errors?: Object }}
 */
export function buildBookingPayload(source) {
  const fields = extractFormFields(source);
  const { valid, errors } = validateBookingFields(fields);

  if (!valid) {
    return { ok: false, errors };
  }

  const payload = {
    fullName: fields.fullName,
    phone: fields.phone,
    email: fields.email || "",
    service: fields.service,
    eventDate: fields.eventDate,
    eventLocation: fields.eventLocation || "",
    guestCount: fields.guestCount || "",
    notes: fields.notes || fields.message || "",
    submittedAt: new Date().toISOString(),
  };

  return { ok: true, payload };
}
