/**
 * whatsapp.js
 * -----------------------------------------------------------------------
 * Direct WhatsApp integration bridge.
 * Takes a validated booking payload (see booking.js), formats a clean,
 * professional message template, URL-encodes it, and opens the
 * "wa.me/<number>" deep link in a new window/tab.
 * -----------------------------------------------------------------------
 */

const DEFAULT_WHATSAPP_NUMBER = "254794891348";

/**
 * Build the human-readable WhatsApp message body from a booking payload.
 * Kept intentionally plain-text and WhatsApp-formatting-friendly
 * (asterisks for bold, underscores for italics are WhatsApp conventions).
 *
 * @param {Object} payload - normalized booking payload from booking.js
 * @returns {string}
 */
export function formatBookingMessage(payload = {}) {
  const {
    fullName = "N/A",
    phone = "N/A",
    email = "",
    service = "N/A",
    eventDate = "N/A",
    eventLocation = "",
    guestCount = "",
    notes = "",
  } = payload;

  const lines = [
    "*NEW BOOKING REQUEST*",
    "",
    `*Name:* ${fullName}`,
    `*Phone:* ${phone}`,
  ];

  if (email) lines.push(`*Email:* ${email}`);

  lines.push(`*Service:* ${service}`, `*Preferred Date:* ${eventDate}`);

  if (eventLocation) lines.push(`*Location:* ${eventLocation}`);
  if (guestCount) lines.push(`*Estimated Guests:* ${guestCount}`);
  if (notes) lines.push("", `*Additional Notes:*`, notes);

  lines.push("", "_Sent via the website booking form._");

  return lines.join("\n");
}

/**
 * URL-encode a message body for safe inclusion in a wa.me link.
 * @param {string} message
 * @returns {string}
 */
export function encodeWhatsAppMessage(message) {
  return encodeURIComponent(message);
}

/**
 * Build the full wa.me deep link for a given number and message.
 * @param {string} message - plain text message (not yet encoded)
 * @param {string} [number] - destination WhatsApp number, digits only
 * @returns {string}
 */
export function buildWhatsAppLink(message, number = DEFAULT_WHATSAPP_NUMBER) {
  const cleanNumber = String(number).replace(/\D/g, "");
  const encoded = encodeWhatsAppMessage(message);
  return `https://wa.me/${cleanNumber}?text=${encoded}`;
}

/**
 * Full pipeline: take a booking payload, format it, and open the
 * WhatsApp deep link in a new browser tab/window.
 *
 * @param {Object} payload - normalized booking payload from booking.js
 * @param {Object} [options]
 * @param {string} [options.number] - destination WhatsApp number override
 * @param {string} [options.target="_blank"] - window.open target
 * @returns {{ url: string, windowRef: Window|null }}
 */
export function sendBookingToWhatsApp(payload, options = {}) {
  const { number = DEFAULT_WHATSAPP_NUMBER, target = "_blank" } = options;

  const message = formatBookingMessage(payload);
  const url = buildWhatsAppLink(message, number);

  const windowRef = window.open(url, target, "noopener,noreferrer");

  if (!windowRef) {
    console.warn(
      "[whatsapp] window.open was blocked by the browser. " +
        "Consider surfacing a fallback link to the user: " +
        url
    );
  }

  return { url, windowRef };
}

/**
 * Convenience helper for quick, ad-hoc WhatsApp messages that don't go
 * through the full booking payload structure (e.g. a simple "Contact
 * Us" button that just says hello).
 *
 * @param {string} rawMessage
 * @param {string} [number]
 */
export function sendQuickMessageToWhatsApp(rawMessage, number = DEFAULT_WHATSAPP_NUMBER) {
  const url = buildWhatsAppLink(rawMessage, number);
  return window.open(url, "_blank", "noopener,noreferrer");
}
