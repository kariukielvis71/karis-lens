/**
 * app.js
 * -----------------------------------------------------------------------
 * Main execution kernel.
 *
 * Responsibilities:
 *   1. Bootstrap application state (config, content, gallery) via
 *      services/dataLoader.js.
 *   2. Set up global event delegation for modals, buttons, and the
 *      booking form -> booking.js -> whatsapp.js pipeline.
 *   3. Implement a lightweight client-side hash router that listens to
 *      `window.location.hash`. When the hash matches '#admin', it gates
 *      access with a basic credential/token check and, if authorized,
 *      swaps the public display block for the admin control board.
 *
 * This module intentionally contains ZERO markup/CSS. It only calls into
 * `helpers.js` (DOM injection) and expects the presentation layer to
 * expose render functions (public UI, admin UI, modals, etc.) which are
 * wired up via `registerViews()` below.
 * -----------------------------------------------------------------------
 */

import { renderElement, toggleVisibility, delegate, hasAdminToken, setAdminToken } from "./utilities/helpers.js";
import { buildBookingPayload } from "./utilities/booking.js";
import { sendBookingToWhatsApp } from "./utilities/whatsapp.js";
import { bootstrapAppState, invalidateCache, loadGallery } from "./services/dataLoader.js";
import { apiClient } from "./utilities/api.js";

/* ------------------------------------------------------------------ */
/*  App-wide state container                                           */
/* ------------------------------------------------------------------ */

const state = {
  config: null,
  content: null,
  gallery: { items: [], source: null },
  currentRoute: "public",
  isAdminAuthorized: false,
};

/** DOM anchor selectors the presentation layer is expected to provide. */
const SELECTORS = {
  publicRoot: "#app-public",
  adminRoot: "#app-admin",
  modalRoot: "#app-modal",
};

/**
 * Registry of presentation-layer render functions. app.js does not know
 * how to draw markup; it only knows *when* to call these hooks. The
 * presentation layer calls `registerViews(...)` once at startup to wire
 * itself in.
 */
const views = {
  renderPublicView: null, // (targetSelector, appState) => string|HTMLElement
  renderAdminView: null, // (targetSelector, appState) => string|HTMLElement
  renderLoginPrompt: null, // (targetSelector) => string|HTMLElement
  renderModal: null, // (targetSelector, modalConfig) => string|HTMLElement
};

/**
 * Called by the presentation layer to register its DOM-building
 * functions with the kernel. Keeps app.js free of markup.
 * @param {Partial<typeof views>} implementations
 */
export function registerViews(implementations = {}) {
  Object.assign(views, implementations);
}

/* ------------------------------------------------------------------ */
/*  Hash router                                                        */
/* ------------------------------------------------------------------ */

const ADMIN_HASH = "#admin";

/**
 * Central route handler triggered on load and on every hashchange.
 * Toggles between the public display block and the admin dashboard.
 */
function handleRouteChange() {
  const hash = window.location.hash || "";

  if (hash.startsWith(ADMIN_HASH)) {
    state.currentRoute = "admin";
    enterAdminRoute();
    return;
  }

  state.currentRoute = "public";
  enterPublicRoute();
}

/**
 * Show the public UI block, hide the admin block.
 */
function enterPublicRoute() {
  toggleVisibility(SELECTORS.publicRoot, true);
  toggleVisibility(SELECTORS.adminRoot, false);

  if (typeof views.renderPublicView === "function") {
    renderElement(SELECTORS.publicRoot, () => views.renderPublicView(SELECTORS.publicRoot, state));
  }
}

/**
 * Gate access to '#admin'. If a valid-looking token is already stored,
 * swap straight to the admin control board. Otherwise render a login
 * prompt (owned by the presentation layer) and wait for credential
 * submission via delegated events (see wireAdminLogin()).
 */
function enterAdminRoute() {
  toggleVisibility(SELECTORS.publicRoot, false);
  toggleVisibility(SELECTORS.adminRoot, true);

  state.isAdminAuthorized = hasAdminToken();

  if (state.isAdminAuthorized) {
    mountAdminDashboard();
  } else if (typeof views.renderLoginPrompt === "function") {
    renderElement(SELECTORS.adminRoot, () => views.renderLoginPrompt(SELECTORS.adminRoot));
  } else {
    console.warn("[app] No renderLoginPrompt view registered; admin route cannot render.");
  }
}

/**
 * Swap the admin block over to the actual control board, refreshing
 * gallery data from the cloud so the dashboard reflects live state.
 */
async function mountAdminDashboard() {
  if (typeof views.renderAdminView !== "function") {
    console.warn("[app] No renderAdminView view registered; admin dashboard cannot render.");
    return;
  }

  invalidateCache("gallery");
  const gallery = await loadGallery({}, { forceRefresh: true });
  state.gallery = gallery;

  renderElement(SELECTORS.adminRoot, () => views.renderAdminView(SELECTORS.adminRoot, state));
}

/**
 * Wire up the hash router: initial route resolution + listen for changes.
 */
function initRouter() {
  window.addEventListener("hashchange", handleRouteChange);
  handleRouteChange(); // resolve initial state on load
}

/**
 * Programmatic navigation helper, exported for the presentation layer
 * (e.g. a "Back to site" button inside the admin dashboard).
 * @param {string} hash - e.g. '#admin' or '' for public root
 */
export function navigateTo(hash) {
  window.location.hash = hash;
}

/* ------------------------------------------------------------------ */
/*  Admin authentication                                               */
/* ------------------------------------------------------------------ */

/**
 * Basic credential token check. In production this should call a
 * Cloudflare Worker auth endpoint that validates credentials and issues
 * a short-lived signed token; this function performs that round trip
 * and persists the returned token via helpers.js on success.
 *
 * @param {string} username
 * @param {string} password
 * @returns {Promise<{ ok: boolean, error?: string }>}
 */
async function attemptAdminLogin(username, password) {
  try {
    const response = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });

    const body = await response.json().catch(() => null);

    if (!response.ok || !body?.token) {
      return { ok: false, error: body?.error || "Invalid credentials." };
    }

    setAdminToken(body.token);
    return { ok: true };
  } catch (err) {
    return { ok: false, error: "Unable to reach the authentication service." };
  }
}

/**
 * Delegate submission of the admin login form (presentation layer is
 * expected to render a form with [data-role="admin-login-form"] and
 * inputs named "username"/"password").
 */
function wireAdminLogin() {
  delegate(document, "submit", '[data-role="admin-login-form"]', async (event, form) => {
    event.preventDefault();

    const formData = new FormData(form);
    const username = formData.get("username");
    const password = formData.get("password");

    const result = await attemptAdminLogin(username, password);

    if (result.ok) {
      state.isAdminAuthorized = true;
      mountAdminDashboard();
    } else {
      form.dispatchEvent(
        new CustomEvent("admin-login-error", { bubbles: true, detail: { error: result.error } })
      );
    }
  });
}

/* ------------------------------------------------------------------ */
/*  Booking form -> WhatsApp pipeline                                   */
/* ------------------------------------------------------------------ */

/**
 * Delegate submission of any booking form
 * (expected selector: [data-role="booking-form"]).
 */
function wireBookingForm() {
  delegate(document, "submit", '[data-role="booking-form"]', (event, form) => {
    event.preventDefault();

    const formData = new FormData(form);
    const result = buildBookingPayload(formData);

    if (!result.ok) {
      form.dispatchEvent(
        new CustomEvent("booking-validation-error", { bubbles: true, detail: { errors: result.errors } })
      );
      return;
    }

    const whatsappNumber = state.config?.business?.whatsappNumber;
    sendBookingToWhatsApp(result.payload, whatsappNumber ? { number: whatsappNumber } : {});

    form.dispatchEvent(new CustomEvent("booking-submitted", { bubbles: true, detail: { payload: result.payload } }));
    form.reset();
  });
}

/* ------------------------------------------------------------------ */
/*  Modal + misc UI event delegation                                   */
/* ------------------------------------------------------------------ */

/**
 * Generic modal open/close delegation.
 * Open trigger:  any element with [data-modal-target="modal-id"]
 * Close trigger:  any element with [data-modal-close]
 */
function wireModalDelegation() {
  delegate(document, "click", "[data-modal-target]", (event, trigger) => {
    const modalId = trigger.getAttribute("data-modal-target");

    if (typeof views.renderModal === "function") {
      renderElement(SELECTORS.modalRoot, () => views.renderModal(SELECTORS.modalRoot, { modalId, state }));
    }

    toggleVisibility(SELECTORS.modalRoot, true);
  });

  delegate(document, "click", "[data-modal-close]", () => {
    toggleVisibility(SELECTORS.modalRoot, false);
  });
}

/**
 * Delegated handler for admin gallery uploads. Expects a file input
 * with [data-role="gallery-upload-input"] inside a form carrying
 * data attributes for metadata (title/category), e.g.
 *   <input data-role="gallery-upload-input" name="file" data-title-field="title" ... />
 */
function wireGalleryUpload() {
  delegate(document, "change", '[data-role="gallery-upload-input"]', async (event, input) => {
    const file = input.files?.[0];
    if (!file) return;

    const form = input.closest("form");
    const metadata = form
      ? Object.fromEntries(new FormData(form).entries())
      : {};
    delete metadata.file;

    input.dispatchEvent(new CustomEvent("upload-started", { bubbles: true }));

    try {
      const result = await apiClient.uploadFile(file, metadata, (percent) => {
        input.dispatchEvent(new CustomEvent("upload-progress", { bubbles: true, detail: { percent } }));
      });

      invalidateCache("gallery");
      input.dispatchEvent(new CustomEvent("upload-success", { bubbles: true, detail: { result } }));

      if (state.currentRoute === "admin") {
        mountAdminDashboard();
      }
    } catch (err) {
      input.dispatchEvent(new CustomEvent("upload-error", { bubbles: true, detail: { error: err.message } }));
    }
  });
}

/* ------------------------------------------------------------------ */
/*  Bootstrap                                                           */
/* ------------------------------------------------------------------ */

/**
 * Application entry point. Call this once from index.html after DOM
 * content has loaded and the presentation layer has registered its
 * views via registerViews().
 */
export async function initApp() {
  try {
    const { config, content, gallery } = await bootstrapAppState();
    state.config = config;
    state.content = content;
    state.gallery = gallery;
  } catch (err) {
    console.error("[app] Failed to bootstrap application state:", err);
  }

  wireBookingForm();
  wireModalDelegation();
  wireAdminLogin();
  wireGalleryUpload();

  initRouter();
}

// Auto-bootstrap once the DOM is ready, unless the host page opts out
// by setting `window.__SKIP_APP_AUTOSTART__ = true` before this module loads
// (useful for tests or a presentation layer that wants full manual control).
if (typeof document !== "undefined" && !window.__SKIP_APP_AUTOSTART__) {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initApp);
  } else {
    initApp();
  }
}
