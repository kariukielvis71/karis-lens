/**
 * Card.js
 * A single reusable card template used for two contexts:
 *   1. variant: 'service'  — a service listing (photography package, video package, etc.)
 *   2. variant: 'media'    — a gallery/portfolio media tile (image or video thumbnail)
 *
 * This module contains NO fetch/data logic. It is a pure function of its input.
 *
 * @param {Object} data
 * @param {'service'|'media'} [data.variant='media']
 *
 *  --- shared ---
 * @param {string}  [data.id]            Unique id, echoed as data-id for event delegation upstream.
 * @param {string}  data.title
 *
 *  --- variant: 'service' ---
 * @param {string}  [data.index]         e.g. "01" — display order label.
 * @param {string}  [data.description]
 * @param {string}  [data.priceLabel]    e.g. "From KES 25,000"
 * @param {string}  [data.durationLabel] e.g. "3–4 Hours"
 *
 *  --- variant: 'media' ---
 * @param {string}  [data.mediaSrc]      Image or poster URL.
 * @param {'image'|'video'} [data.mediaType='image']
 * @param {string}  [data.category]      Filter category e.g. "Weddings", "Portraits".
 * @param {string}  [data.alt]           Alt text for accessibility.
 *
 * @returns {string} HTML template string for the <article class="card"> element.
 */
export function Card(data = {}) {
  const { variant = 'media', id = '' } = data;
  return variant === 'service' ? serviceCardTemplate(data, id) : mediaCardTemplate(data, id);
}

function serviceCardTemplate(
  {
    index = '01',
    title = 'Untitled Service',
    description = '',
    priceLabel = '',
    durationLabel = '',
  },
  id
) {
  return `
    <article class="card card--service" data-component="card" data-variant="service" data-id="${id}">
      <span class="card__index">${index}</span>
      <h3 class="card__title">${title}</h3>
      <p class="card__desc">${description}</p>
      <div class="card__meta">
        <span>${durationLabel}</span>
        <span>${priceLabel}</span>
      </div>
    </article>
  `;
}

function mediaCardTemplate(
  {
    title = '',
    mediaSrc = '',
    mediaType = 'image',
    category = '',
    alt = '',
  },
  id
) {
  const mediaEl =
    mediaType === 'video'
      ? `<video src="${mediaSrc}" muted loop playsinline preload="metadata"></video>`
      : `<img src="${mediaSrc}" alt="${alt || title}" loading="lazy" />`;

  return `
    <article
      class="card card--media"
      data-component="card"
      data-variant="media"
      data-id="${id}"
      data-category="${category}"
      tabindex="0"
      role="button"
      aria-label="Open ${title || 'media item'} in lightbox"
    >
      <div class="card__media-frame">${mediaEl}</div>
      <div class="card__scrim">
        <span class="card__tag">${category}</span>
        <h3 class="card__title">${title}</h3>
      </div>
      <span class="card__expand-icon" aria-hidden="true">⤢</span>
    </article>
  `;
}

export default Card;
