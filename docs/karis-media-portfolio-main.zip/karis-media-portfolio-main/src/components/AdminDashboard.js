/**
 * AdminDashboard.js
 * Private workspace shell for studio staff to upload and manage gallery media.
 *
 * Pure presentation: renders the drag-and-drop zone, metadata form fields,
 * an upload queue list, and action buttons. No upload/fetch engine lives
 * here — the consuming app wires drop/change/submit handlers separately.
 *
 * @param {Object} config
 * @param {string} [config.staffName='Studio Team']
 * @param {Array<{label:string, value:string}>} [config.categoryOptions]
 * @param {Array<{id:string, name:string, sizeLabel:string, thumbSrc?:string, status?:'queued'|'uploading'|'done'|'error'}>} [config.queueItems]
 * @param {{totalAssets:number, storageUsedLabel:string, pendingCount:number}} [config.stats]
 * @returns {string} HTML template string for the dashboard layout.
 */
export function AdminDashboard({
  staffName = 'Studio Team',
  categoryOptions = [
    { label: 'Weddings', value: 'weddings' },
    { label: 'Portraits', value: 'portraits' },
    { label: 'Events', value: 'events' },
    { label: 'Commercial', value: 'commercial' },
    { label: 'Film & Video', value: 'film' },
  ],
  queueItems = [],
  stats = { totalAssets: 0, storageUsedLabel: '0 GB', pendingCount: 0 },
} = {}) {
  const categoryOptionsHtml = categoryOptions
    .map((opt) => `<option value="${opt.value}">${opt.label}</option>`)
    .join('');

  const queueHtml = queueItems.length
    ? queueItems.map(queueItemTemplate).join('')
    : `<li class="upload-queue__empty">No files queued yet — drag media above to begin.</li>`;

  return `
    <div class="admin-dashboard" data-component="admin-dashboard">

      <header class="admin-dashboard__header">
        <div>
          <p class="eyebrow">Studio Workspace</p>
          <h2>Media Upload Console</h2>
        </div>
        <div class="admin-dashboard__session">
          <span class="admin-dashboard__session-name">${staffName}</span>
          <button class="btn btn--ghost btn--sm" type="button" data-action="logout">Sign Out</button>
        </div>
      </header>

      <section class="admin-stats" aria-label="Workspace summary">
        <div class="admin-stats__item panel">
          <span class="admin-stats__value">${stats.totalAssets}</span>
          <span class="admin-stats__label">Total Assets</span>
        </div>
        <div class="admin-stats__item panel">
          <span class="admin-stats__value">${stats.storageUsedLabel}</span>
          <span class="admin-stats__label">Storage Used</span>
        </div>
        <div class="admin-stats__item panel">
          <span class="admin-stats__value">${stats.pendingCount}</span>
          <span class="admin-stats__label">Pending Review</span>
        </div>
      </section>

      <div class="admin-dashboard__grid">

        <section class="admin-panel panel" aria-labelledby="upload-zone-heading">
          <h3 id="upload-zone-heading" class="admin-panel__title">Upload Media</h3>

          <div class="dropzone" data-dropzone tabindex="0" role="button" aria-label="Drag and drop files, or click to browse">
            <span class="dropzone__icon" aria-hidden="true">⤒</span>
            <p class="dropzone__title">Drag &amp; drop files here</p>
            <p class="dropzone__hint">or click to browse — JPG, PNG, MP4 up to 500MB</p>
            <input class="visually-hidden" type="file" id="admin-file-input" multiple accept="image/*,video/*" />
          </div>

          <form class="admin-form" data-form="media-meta">
            <div class="field">
              <label for="admin-title">Title</label>
              <input type="text" id="admin-title" name="title" placeholder="e.g. Amara & James — First Dance" />
            </div>

            <div class="admin-form__row">
              <div class="field">
                <label for="admin-category">Category</label>
                <select id="admin-category" name="category">
                  ${categoryOptionsHtml}
                </select>
              </div>

              <div class="field">
                <label for="admin-visibility">Visibility</label>
                <select id="admin-visibility" name="visibility">
                  <option value="public">Public — Gallery</option>
                  <option value="draft">Draft — Hidden</option>
                  <option value="featured">Featured — Homepage</option>
                </select>
              </div>
            </div>

            <div class="field">
              <label for="admin-notes">Internal Notes</label>
              <textarea id="admin-notes" name="notes" rows="3" placeholder="Optional notes for the team (not shown publicly)"></textarea>
            </div>

            <div class="admin-form__actions">
              <button class="btn btn--secondary" type="reset">Clear</button>
              <button class="btn btn--primary" type="submit" data-action="upload">Upload &amp; Publish</button>
            </div>
          </form>
        </section>

        <section class="admin-panel panel" aria-labelledby="queue-heading">
          <div class="admin-panel__header-row">
            <h3 id="queue-heading" class="admin-panel__title">Upload Queue</h3>
            <button class="btn btn--ghost btn--sm" type="button" data-action="clear-queue">Clear All</button>
          </div>

          <ul class="upload-queue" data-queue-list>
            ${queueHtml}
          </ul>
        </section>

      </div>
    </div>
  `;
}

function queueItemTemplate({ id, name, sizeLabel, thumbSrc = '', status = 'queued' }) {
  const statusLabelMap = {
    queued: 'Queued',
    uploading: 'Uploading…',
    done: 'Published',
    error: 'Failed',
  };

  return `
    <li class="upload-queue__item" data-id="${id}" data-status="${status}">
      <div class="upload-queue__thumb">
        ${thumbSrc ? `<img src="${thumbSrc}" alt="" />` : `<span aria-hidden="true">▤</span>`}
      </div>
      <div class="upload-queue__meta">
        <p class="upload-queue__name">${name}</p>
        <p class="upload-queue__size">${sizeLabel}</p>
      </div>
      <span class="upload-queue__status" data-status-badge>${statusLabelMap[status] || status}</span>
      <button class="btn btn--icon btn--sm" type="button" data-action="remove-item" aria-label="Remove ${name} from queue">✕</button>
    </li>
  `;
}

export default AdminDashboard;
