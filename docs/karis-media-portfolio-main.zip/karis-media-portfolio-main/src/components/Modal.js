/**
 * Modal.js
 * An immersive backdrop lightbox shell. Used for:
 *   - Gallery media previews (image/video full view)
 *   - Any dynamic dialog content (confirmation, expanded form, etc.)
 *
 * This module renders structural markup only. It does NOT manage its own
 * global state — the consumer decides when to inject it into the DOM and
 * toggle the `is-open` class. A small optional helper (initModalInteractions)
 * is included for close-button / backdrop / Escape-key wiring, kept separate
 * from the template itself.
 *
 * @param {Object} config
 * @param {string} [config.id='modal-root']   DOM id for the modal root, for aria-controls linkage.
 * @param {string} [config.labelledBy]        Id of an element that labels the dialog (a11y).
 * @param {string} [config.bodyHtml='']       Arbitrary inner content — an image, video, or form markup.
 * @param {boolean} [config.showClose=true]
 * @returns {string} HTML template string for the modal overlay.
 */
export function Modal({
  id = 'modal-root',
  labelledBy = '',
  bodyHtml = '',
  showClose = true,
} = {}) {
  return `
    <div
      class="modal-overlay"
      id="${id}"
      data-component="modal"
      data-state="closed"
      role="dialog"
      aria-modal="true"
      ${labelledBy ? `aria-labelledby="${labelledBy}"` : ''}
    >
      <div class="modal-overlay__backdrop" data-modal-dismiss></div>

      <div class="modal-shell">
        ${
          showClose
            ? `<button class="btn btn--icon modal-shell__close" type="button" data-modal-dismiss aria-label="Close preview">✕</button>`
            : ''
        }
        <div class="modal-shell__body" data-modal-body>
          ${bodyHtml}
        </div>
      </div>
    </div>
  `;
}

/**
 * Pre-built body content for a media lightbox (image or video), for convenience.
 * Still just markup — no data-fetching.
 *
 * @param {Object} media
 * @param {'image'|'video'} [media.type='image']
 * @param {string} media.src
 * @param {string} [media.caption]
 * @returns {string}
 */
export function ModalMediaBody({ type = 'image', src = '', caption = '' } = {}) {
  const mediaEl =
    type === 'video'
      ? `<video src="${src}" controls autoplay class="modal-media"></video>`
      : `<img src="${src}" alt="${caption}" class="modal-media" />`;

  return `
    ${mediaEl}
    ${caption ? `<p class="modal-caption">${caption}</p>` : ''}
  `;
}

/**
 * Wires dismiss interactions (backdrop click, close button, Escape key)
 * for a Modal already injected into the DOM.
 *
 * @param {string} id  The modal root id passed to Modal().
 */
export function initModalInteractions(id = 'modal-root') {
  const overlay = document.getElementById(id);
  if (!overlay) return;

  const close = () => {
    overlay.setAttribute('data-state', 'closed');
    document.body.classList.remove('modal-lock');
  };

  const open = () => {
    overlay.setAttribute('data-state', 'open');
    document.body.classList.add('modal-lock');
  };

  overlay.querySelectorAll('[data-modal-dismiss]').forEach((el) => {
    el.addEventListener('click', close);
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && overlay.getAttribute('data-state') === 'open') close();
  });

  return { open, close };
}

export default Modal;
