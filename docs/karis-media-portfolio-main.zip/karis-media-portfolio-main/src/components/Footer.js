/**
 * Footer.js
 * Site footer for Karis Media Production.
 *
 * Pure presentation module — accepts branding/link data, returns a template
 * string. The copyright year is computed at render time (Date), which is
 * simple UI data, not business logic.
 *
 * @param {Object} config
 * @param {string} [config.brandName='Karis Media Production']
 * @param {string} [config.tagline]
 * @param {Array<{label:string, href:string}>} [config.quickLinks]
 * @param {Array<{label:string, href:string}>} [config.social]
 * @param {{email:string, phone:string, location:string}} [config.contact]
 * @returns {string} HTML template string for the <footer> element.
 */
export function Footer({
  brandName = 'Karis Media Production',
  tagline = 'Turning moments into memories — one frame at a time.',
  quickLinks = [
    { label: 'Services', href: 'index.html#services' },
    { label: 'Gallery', href: 'index.html#gallery' },
    { label: 'About', href: 'about.html' },
    { label: 'Book a Session', href: 'index.html#booking' },
  ],
  social = [
    { label: 'Instagram', href: '#' },
    { label: 'YouTube', href: '#' },
    { label: 'TikTok', href: '#' },
  ],
  contact = {
    email: 'hello@karismedia.co',
    phone: '+254 700 000 000',
    location: 'Nairobi, Kenya',
  },
} = {}) {
  const year = new Date().getFullYear();

  const quickLinksHtml = quickLinks
    .map((link) => `<li><a class="footer-links__item" href="${link.href}">${link.label}</a></li>`)
    .join('');

  const socialHtml = social
    .map((s) => `<a class="footer-social__item" href="${s.href}" aria-label="${s.label}">${s.label}</a>`)
    .join('');

  return `
    <footer class="site-footer" data-component="footer">
      <div class="container footer-grid">
        <div class="footer-brand">
          <p class="site-footer__brand-name">${brandName}</p>
          <p class="site-footer__tagline">${tagline}</p>
          <div class="footer-social" aria-label="Social media links">
            ${socialHtml}
          </div>
        </div>

        <div class="footer-col">
          <p class="eyebrow">Navigate</p>
          <ul class="footer-links">${quickLinksHtml}</ul>
        </div>

        <div class="footer-col">
          <p class="eyebrow">Contact</p>
          <ul class="footer-links">
            <li><a class="footer-links__item" href="mailto:${contact.email}">${contact.email}</a></li>
            <li><a class="footer-links__item" href="tel:${contact.phone.replace(/\s+/g, '')}">${contact.phone}</a></li>
            <li><span class="footer-links__item footer-links__item--static">${contact.location}</span></li>
          </ul>
        </div>
      </div>

      <div class="container site-footer__bottom">
        <p class="site-footer__legal">&copy; ${year} ${brandName}. All rights reserved.</p>
        <a class="site-footer__admin-link" href="admin.html">Studio Login</a>
      </div>
    </footer>
  `;
}

export default Footer;
