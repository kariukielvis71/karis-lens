/**
 * Header.js
 * Sticky navigation for Karis Media Production.
 *
 * Pure presentation: accepts data, returns markup. No fetch, no routing logic.
 * The consumer app is responsible for wiring up the mobile toggle behavior
 * (this module only renders semantic, accessible markup + data-hooks for it).
 *
 * @param {Object}   config
 * @param {string}   [config.activePath='/']   Path of the current page, used to set aria-current.
 * @param {Array<{label:string, href:string}>} [config.links]  Nav links.
 * @param {{label:string, href:string}} [config.cta]           Primary call-to-action button.
 * @returns {string} HTML template string for the <header> element.
 */
export function Header({
  activePath = '/',
  links = [
    { label: 'Home', href: 'index.html' },
    { label: 'Services', href: 'index.html#services' },
    { label: 'Gallery', href: 'index.html#gallery' },
    { label: 'About', href: 'about.html' },
    { label: 'Contact', href: 'index.html#booking' },
  ],
  cta = { label: 'Book a Session', href: 'index.html#booking' },
} = {}) {
  const navLinks = links
    .map((link) => {
      const isActive = link.href.split('#')[0] === activePath;
      return `
        <a
          class="site-header__link"
          href="${link.href}"
          ${isActive ? 'aria-current="page"' : ''}
        >${link.label}</a>
      `;
    })
    .join('');

  return `
    <header class="site-header" data-component="header">
      <div class="container site-header__bar">
        <a href="index.html" class="site-header__brand" aria-label="Karis Media Production — Home">
          Karis <span class="site-header__brand-mark">MEDIA&nbsp;/&nbsp;PROD</span>
        </a>

        <nav class="site-header__nav" data-nav-menu data-open="false" aria-label="Primary">
          ${navLinks}
          <div class="site-header__actions">
            <a class="btn btn--primary" href="${cta.href}">${cta.label}</a>
          </div>
        </nav>

        <button
          class="site-header__toggle"
          type="button"
          data-nav-toggle
          aria-expanded="false"
          aria-controls="site-header-nav"
          aria-label="Toggle navigation menu"
        >
          <span></span><span></span><span></span>
        </button>
      </div>
    </header>
  `;
}

/**
 * Optional helper: wires the mobile menu toggle for the rendered Header markup.
 * Kept separate from the template so this file remains a pure UI module —
 * call this once after injecting Header() into the DOM, if mobile toggling is needed.
 *
 * @param {ParentNode} [root=document] Root node to query within.
 */
export function initHeaderInteractions(root = document) {
  const toggle = root.querySelector('[data-nav-toggle]');
  const nav = root.querySelector('[data-nav-menu]');
  if (!toggle || !nav) return;

  toggle.addEventListener('click', () => {
    const isOpen = toggle.getAttribute('aria-expanded') === 'true';
    toggle.setAttribute('aria-expanded', String(!isOpen));
    nav.setAttribute('data-open', String(!isOpen));
  });
}

export default Header;
