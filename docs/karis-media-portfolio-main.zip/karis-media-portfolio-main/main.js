/**
 * main.js
 * Thin composition entry point. Mounts presentation components into their
 * root nodes and wires purely-structural interactions (nav toggle, modal
 * open/close, filter button aria-pressed state).
 *
 * Intentionally contains NO data fetching, form submission, or upload
 * logic — those belong to a separate application/service layer that
 * consumes these UI modules.
 */

import { Header, initHeaderInteractions } from './components/Header.js';
import { Footer } from './components/Footer.js';
import { Modal, initModalInteractions } from './components/Modal.js';

document.addEventListener('DOMContentLoaded', () => {
  // ---- Mount Header ----
  const headerRoot = document.getElementById('header-root');
  if (headerRoot) {
    headerRoot.innerHTML = Header({ activePath: currentPath() });
    initHeaderInteractions(headerRoot);
  }

  // ---- Mount Footer ----
  const footerRoot = document.getElementById('footer-root');
  if (footerRoot) {
    footerRoot.innerHTML = Footer();
  }

  // ---- Mount Modal shell (empty until a gallery card requests content) ----
  const modalMount = document.getElementById('modal-mount');
  if (modalMount) {
    modalMount.innerHTML = Modal({ id: 'lightbox' });
    initModalInteractions('lightbox');
  }

  // ---- Purely structural: gallery filter button active-state toggling ----
  // (Actual show/hide filtering of cards is left to the app/data layer.)
  document.querySelectorAll('[data-mount="gallery-filters"] .gallery-filters__btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      document
        .querySelectorAll('[data-mount="gallery-filters"] .gallery-filters__btn')
        .forEach((b) => b.setAttribute('aria-pressed', 'false'));
      btn.setAttribute('aria-pressed', 'true');
    });
  });
});

function currentPath() {
  return window.location.pathname.split('/').pop() || 'index.html';
}
